package com.microsoft.azure.documentdb;

enum ReadType {
    Feed,
    Query
}
